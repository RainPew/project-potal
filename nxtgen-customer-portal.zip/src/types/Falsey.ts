export type Falsey = false | null | undefined | 0 | "";
