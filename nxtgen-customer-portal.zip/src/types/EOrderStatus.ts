export enum EOrderStatus {
  A = "Approved",
  I = "Invoiced",
  N = "New",
  P = "Paid",
  T = "Template",
  X = "Deleted",
}
