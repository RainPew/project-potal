export const ACTIVE_COLOR = "#E30613";
export const ACTIVE_COLOR_ICON = "#E30613";
export const DEFAULT_COLOR = "#102a47";
export const DEFAULT_COLOR_ICON = "#8da4be";
export const ACTIVE_BG = "rgba(227, 6, 19, 0.05)";
export const DEFAULT_BG = "#fff";
export const SETTING_COLOR = "#C4C4C4";
export const COMPANY_COLOR = "#576F8B";
export const DEFAULT_BG_PLACE_ORDER = "#E5E5E5";

export const GREEN_COLOR = "#25A567";
